﻿using OnlineCartBusinessLayerLib;//Using Business Layer Library
using OnlineCartEntitiesLib;//Using Entities Library
using OnlineCartExceptionLib;//Using Exception Library
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineShoppingCart.Controllers
{
    public class SecurityController : ApiController
    {
        /// <summary>
        /// Method to Get the Username of the User
        /// </summary>
        /// <param name="name">Takes the Parameter as UserName</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/Security/GetUserName/{name}")]
        public HttpResponseMessage GetUserName(string name)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "UserName Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var username = bll.GetUsername(name);
                //Creates the response and has the list of products
                msg = Request.CreateResponse<Login>(username);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to get the password of the User
        /// </summary>
        /// <param name="pwd">takes the parameter as Password</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/Security/GetPassword/{pwd}")]
        public HttpResponseMessage GetPassword(string pwd)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Password Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var pswd = bll.GetPassword(pwd);
                //Creates the response and has the list of products
                msg = Request.CreateResponse<Login>(pswd);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
    }
}
