﻿using Newtonsoft.Json;
using OnlineShoppingCartMVCClient.Models;
using System;
using System.Net.Http;
using System.Web.Mvc;
using System.Web.Security;

namespace OnlineShoppingCartMVCClient.Controllers
{
    public class SecurityController : Controller
    {
        // GET: Security
        /// <summary>
        /// ActionResult to get the Login Form to the User
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Login()
        {
            //Specifying the ReturnUrl in the QueryString
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            //Adding this Url to the View
            ViewData.Add("returnUrl", returnUrl);
            //Returning View
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login login)
        {
            //LocalHost Connection of API
            Uri uri = new Uri("http://localhost:58092/api/");
            //Calling the API
            using (var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var uname = client.GetStringAsync("Security/GetUserName/" + login.UserName).Result;
                //Deserializing the Json Object to C# 
                var name = JsonConvert.DeserializeObject<Login>(uname);
                //Assigning the Username to a Variable
                string username = name.UserName;
                //Sends a Get Request to the Specified Uri
                var pswd = client.GetStringAsync("Security/GetPassword/" + login.Password).Result;
                //Deserializing the Json Object to C# 
                var pwd = JsonConvert.DeserializeObject<Login>(pswd);
                //Assigning the Username to a Variable
                string password = pwd.Password;

                //Checks the condition, If user entered Username, Password matches with the Username, Password present in the Database or not
                if ((login.UserName.Equals(username)) && (login.Password.Equals(password)))
                {
                    //Setting the Cookie
                    FormsAuthentication.SetAuthCookie(login.UserName, false);
                    //User supplies and submits credentials through this form
                    var returnUrl = Request.Form["returnUrl"];
                    //Redirect to the Url
                    return Redirect(returnUrl);
                }
                //If the condition fails, Displays the Error Message
                else
                {
                    //Adding the Error to the Model
                    ModelState.AddModelError("UserName", "UserName & Password are invalid, Please try with another credentials");
                }
                //Specifying the ReturnUrl in the QueryString
                var returnUrl1 = Request.QueryString.Get("ReturnUrl");
                //Adding this Url to the View
                ViewData.Add("returnUrl", returnUrl1);
                //Returning View
                return View();
            }
        }
        /// <summary>
        /// ActionResult for Logout
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Logout()
        {
            //Removes the forms-authentication ticket from the browser
            FormsAuthentication.SignOut();
            //Returning View
            return View();
        }
    }
}