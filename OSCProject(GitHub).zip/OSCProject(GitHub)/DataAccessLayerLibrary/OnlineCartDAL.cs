﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using OnlineCartEntitiesLib;//Using Entities Library
using OnlineCartExceptionLib;//Using Exception Library
using System.Configuration;

namespace OnlineCartDataAccessLayerLib
{
    public class OnlineCartDAL : IOnlineCartDAL
    {
        //Connection variable declaration for the SqlConnection
        SqlConnection con;
        //Command variable declaration for the SqlCommand
        SqlCommand cmd;
        //Constructor for the OnlineCartDAL class
        public OnlineCartDAL()
        {
            //Establishing the Connection
            con = new SqlConnection();
            //Giving the Connection String
            con.ConnectionString = ConfigurationManager.ConnectionStrings["sqlconstr"].ConnectionString;
        }
        /// <summary>
        /// Method to get the list of products based on the Product Name searched
        /// </summary>
        /// <param name="name">Takes a parameter as Product Name</param>
        /// <returns>Returns a List of Products</returns>
        public List<Product> GetProductsByProductName(string name)
        {
            //Object creation for the List of Product
            List<Product> lstPrdt = new List<Product>();
            //Try If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select productid, image, productname, price from tbl_product where productname like @pn";
                //Clearing the Parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding the new Parameter
                cmd.Parameters.AddWithValue("@pn", "%" + name + "%");
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting Connection for our SQL Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                //Loops mentioned fields in the query on my table
                while (sdr.Read())
                {
                    //Object creation for the object
                    Product prdt = new Product
                    {
                        ProductId = (int)sdr[0],
                        Image = sdr[1].ToString(),
                        ProductName = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    //Adding the Product Object to the List of Product Object
                    lstPrdt.Add(prdt);
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other Exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Returning the Object of List of Product
            return lstPrdt;
        }
        /// <summary>
        /// Method to get the list of products based on the Category Name searched
        /// </summary>
        /// <param name="name">Takes a parameter as Category Name</param>
        /// <returns>Returns a List of Products</returns>
        public List<Product> GetProductsByCategoryName(string name)
        {
            //Object creation for the List of Product
            List<Product> lstPdt = new List<Product>();
            //Try If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select p.productid,p.image,p.productname,p.price from tbl_product as p join " +
                    "tbl_category as c on p.categoryid = c.categoryid and c.categoryname like @cn";
                //Clearing the Parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding the new Parameter
                cmd.Parameters.AddWithValue("@cn", "%" + name + "%");
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting Connection for our SQL Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                //Loops mentioned fields in the query on my table
                while (sdr.Read())
                {
                    //Object creation for the object
                    Product pdt = new Product
                    {
                        ProductId = (int)sdr[0],
                        Image = sdr[1].ToString(),
                        ProductName = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    //Adding the Product Object to the List of Product Object
                    lstPdt.Add(pdt);
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other Exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Returning the Object of List of Product
            return lstPdt;
        }
        /// <summary>
        /// Method to get the Full Product Details by using the Product Id
        /// </summary>
        /// <param name="id">Takes a parameter as Product Id</param>
        /// <returns>Returns a single product</returns>
        public Product GetProductDetailsById(int id)
        {
            //Object creation for the Product
            Product prd = new Product();
            //Try, If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select * from tbl_product where productid = @id";
                //Clearing the Parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding the new Parameter
                cmd.Parameters.AddWithValue("@id", id);
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting Connection for our SQL Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                //Loops mentioned fields in the query on my table
                while (sdr.Read())
                {
                    prd.ProductId = (int)sdr[0];
                    prd.CategoryId = (int)sdr[1];
                    prd.ProductName = sdr[2].ToString();
                    prd.Image = sdr[3].ToString();
                    prd.Price = Convert.ToDouble(sdr[4]);
                    prd.AvailableOffers = sdr[5].ToString();
                    prd.Content = sdr[6].ToString();
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other Exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Returning the Object of Product
            return prd;
        }
        /// <summary>
        /// Method to get all the available categories in the Online Shopping Site
        /// </summary>
        /// <returns>Returns the List of Categories</returns>
        public List<OnlineCategory> GetAllCategories()
        {
            //Object creation for the List of OnlineCategory
            List<OnlineCategory> lstCat = new List<OnlineCategory>();
            //Try If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select * from tbl_category";
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting Connection for our SQL Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                //Loops for every field in the query on my table
                while (sdr.Read())
                {
                    //Object creation for the OnlineCategory
                    OnlineCategory cat = new OnlineCategory
                    {
                        CategoryId = (int)sdr[0],
                        CategoryName = sdr[1].ToString()
                    };
                    //Adding the OnlineCategory Object to the List of OnlineCategory
                    lstCat.Add(cat);
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other Exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Return the Object of List of OnlineCategory
            return lstCat;
        }
        /// <summary>
        /// Method to add the list of products to the cart
        /// </summary>
        /// <param name="lstOp">Takes the parameter List of OrderProduct</param>
        public void AddToCart(List<OrderProduct> lstOp)
        {
            //Try, If there is no exception
            try
            {
                //Opening the Connection
                con.Open();
                //Loop for each item added to the cart
                foreach (var item in lstOp)
                {
                    //Establishing the Command
                    cmd = new SqlCommand();
                    //Executing the query through CommandText
                    cmd.CommandText = "insert into tbl_order values(@pid,@pname,@price,@img,@qant)";
                    //Clearing the Parameters so that we can add new ones
                    cmd.Parameters.Clear();
                    //Adding the new parameters
                    cmd.Parameters.AddWithValue("@pid", item.ProductId);
                    cmd.Parameters.AddWithValue("@pname", item.ProductName);
                    cmd.Parameters.AddWithValue("@price", item.Price);
                    cmd.Parameters.AddWithValue("@img", item.Image);
                    cmd.Parameters.AddWithValue("@qant", item.Quantity);
                    //Mentioning the type of the Command
                    cmd.CommandType = CommandType.Text;
                    //Setting the Connection for our Sql Server
                    cmd.Connection = con;
                    //Executes the command and returns the number of rows affected
                    int recordsAffected = cmd.ExecuteNonQuery();
                    //Checking the Condition if affected records are "0" or not
                    if (recordsAffected == 0)
                    {
                        //If "0", then throws an exception with the specified message
                        throw new Exception("Item cannot be added to cart");
                    }
                }
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other Exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
        }
        /// <summary>
        /// Method to get the list of products present in the cart
        /// </summary>
        /// <returns>Returns the List of OrderProduct</returns>
        public List<OrderProduct> GetCartDetails()
        {
            //Object creation for the List of OrderProduct
            List<OrderProduct> lstOp = new List<OrderProduct>();
            //Try, If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select * from tbl_order";
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting the Connection for our Sql Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                //Loops for every fields in the query on my table
                while (sdr.Read())
                {
                    //Object creqation for the OrderProduct
                    OrderProduct op = new OrderProduct
                    {
                        ProductId = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Price = Convert.ToDouble(sdr[2]),
                        Image = sdr[3].ToString(),
                        Quantity = (int)sdr[4]
                    };
                    //Adding the OrderProduct Object to the List of OrderProduct Object
                    lstOp.Add(op);
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Returns the Object of List of OrderProduct
            return lstOp;
        }
        /// <summary>
        /// Method to Post the Product from Cart to Place the Order
        /// </summary>
        /// <param name="op">Takes the Parameter OrderProduct</param>
        public void PostToCart(OrderProduct op)
        {
            //Try, If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "insert into tbl_order values(@pid,@pname,@price,@img,@qnat)";
                //Clearing the Parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding the new parameters
                cmd.Parameters.AddWithValue("@pid", op.ProductId);
                cmd.Parameters.AddWithValue("@pname", op.ProductName);
                cmd.Parameters.AddWithValue("@price", op.Price);
                cmd.Parameters.AddWithValue("@img", op.Image);
                cmd.Parameters.AddWithValue("@img", op.Quantity);
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting the Connection for our Sql Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //Executes the command and returns the number of rows affected
                int recordsAffected = cmd.ExecuteNonQuery();
                //Checking the Condition if affected records are "0" or not
                if (recordsAffected == 0)
                {
                    //If "0", then throws an exception with the specified message
                    throw new Exception("Item cannot be added to cart");
                }
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
        }
        /// <summary>
        /// Method to Delete the Product when it is placed for the order
        /// </summary>
        /// <param name="id">Takes the Parameter as Product Id</param>
        public void DeleteOrderFromCartById(int id)
        {
            //Try, If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "delete from tbl_order where productid = @id";
                //Clearing the Parameter to add the new ones
                cmd.Parameters.Clear();
                //Adding the new parameter
                cmd.Parameters.AddWithValue("@id", id);
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting the Connection for our Sql Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //Executes the command and returns the number of rows affected
                int recordsAffected = cmd.ExecuteNonQuery();
                //Checking the Condition if affected records are "0" or not
                if (recordsAffected == 0)
                {
                    //If "0", then throws an exception with the specified message
                    throw new Exception("Product doesn't exist");
                }
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other Exception exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
        }
        /// <summary>
        /// Method to Get the Username of the User at the time of Login
        /// </summary>
        /// <param name="name">Takes the Parameter as Username</param>
        /// <returns>Returns the Login Object</returns>
        public Login GetUsername(string name)
        {
            //Object creation for Login
            Login login = new Login();
            //Try, If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select username from tbl_UserDetail where username = @un";
                //Clearing the Parameter to add the new ones
                cmd.Parameters.Clear();
                //Adding the new parameter
                cmd.Parameters.AddWithValue("@un", name);
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting the Connection for our Sql Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    login.UserName = sdr[0].ToString();
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other exceptions exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Returns the Object of Login
            return login;
        }
        /// <summary>
        /// Method to Get the Password of the User at the time of Login
        /// </summary>
        /// <param name="pwd">Takes the Parameter as Password</param>
        /// <returns>Returns the Login Object</returns>
        public Login GetPassword(string pwd)
        {
            //Object creation for Login
            Login login = new Login();
            //Try, If there is no exception
            try
            {
                //Establishing the Command
                cmd = new SqlCommand();
                //Executing the query through CommandText
                cmd.CommandText = "select password from tbl_UserDetail where password = @pwd";
                //Clearing the Parameter to add the new ones
                cmd.Parameters.Clear();
                //Adding the new parameter
                cmd.Parameters.AddWithValue("@pwd", pwd);
                //Mentioning the type of the Command
                cmd.CommandType = CommandType.Text;
                //Setting the Connection for our Sql Server
                cmd.Connection = con;
                //Opening the Connection
                con.Open();
                //SqlCommand Object sends the SQL statements to the SqlConnection Object and populate a SqlDataReader Object
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    login.Password = sdr[0].ToString();
                }
                //Closing the DataReader
                sdr.Close();
            }
            //Catch, If any SqlException exists
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Catch, If any other exceptions exists
            catch (Exception ex)
            {
                throw new OnlineException("Some database error occured : " + ex.Message);
            }
            //Finally block is always executed whether exception is handled or not
            finally
            {
                //Closing the Connection with SqlServer
                con.Close();
            }
            //Returns the Object of Login
            return login;
        }
    }
}