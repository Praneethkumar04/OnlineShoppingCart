﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineCartBusinessLayerLib;//Using Business Layer Library
using OnlineCartEntitiesLib;//Using Entities Library
using OnlineCartExceptionLib;//Using Exception Library
namespace OnlineShoppingCart.Controllers
{
    public class OnlineShoppingController : ApiController
    {
        /// <summary>
        /// Method to get the list of products by searching the product name
        /// </summary>
        /// <param name="name">Takes the parameter as Product Name</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/OnlineShopping/GetProductsByProductName/{name}")]
        public HttpResponseMessage GetProductsByProductName(string name)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Records Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var lstPrdt = bll.GetProductsByProductName(name);
                //Creates the response and has the list of products
                msg = Request.CreateResponse<List<Product>>(lstPrdt);
            }
            //Catch, If any custom exception exists
            catch(OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to get the list of products by searching the category name
        /// </summary>
        /// <param name="name">Takes the parameter as Category Name</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/OnlineShopping/GetProductsByCategoryName/{name}")]
        public HttpResponseMessage GetProductsByCategoryName(string name)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Records Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var lstPdt = bll.GetProductsByCategoryName(name);
                //Creates the response and has the list of products
                msg = Request.CreateResponse<List<Product>>(lstPdt);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to get the Product Details using Product Id
        /// </summary>
        /// <param name="id">Takes the parameter as Product Id</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/OnlineShopping/GetProductDetailsById/{id}")]
        public HttpResponseMessage GetProductDetailsById(int id)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Records Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var prd = bll.GetProductDetailsById(id);
                //Creates the response and has the list of products
                msg = Request.CreateResponse<Product>(prd);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to get all the categories present in the Online Shopping Site
        /// </summary>
        /// <returns>Returns the HttpResponseMessage</returns>
        public HttpResponseMessage Get()
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Records Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var lstCat = bll.GetAllCategories();
                //Creates the response and has the list of products
                msg = Request.CreateResponse<List<OnlineCategory>>(lstCat);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to add the products to Cart
        /// </summary>
        /// <param name="lstOp">Takes the parameter List of OrderProduct</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        public HttpResponseMessage Post([FromBody] List<OrderProduct> lstOp)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Products Added");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the Function 
                bll.AddToCart(lstOp);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to post the products which are placed for the Order
        /// </summary>
        /// <param name="op">Takes the parameter OrderProduct</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/OnlineShopping/PostToCart")]
        public HttpResponseMessage PostToCart([FromBody]OrderProduct op)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Products Posted");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the Function 
                bll.PostToCart(op);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to get the products which are present in the Cart
        /// </summary>
        /// <returns>Returns the HttpResponseMessage</returns>
        [Route("api/OnlineShopping/GetCartDetails")]
        public HttpResponseMessage GetCartDetails()
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Products Found");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the function and Storing the result in a variable
                var lstOp = bll.GetCartDetails();
                //Creates the response and has the list of products
                msg = Request.CreateResponse<List<OrderProduct>>(lstOp);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
        /// <summary>
        /// Method to delete the products which are placed for order
        /// </summary>
        /// <param name="id">Takes the parameter as Product Id</param>
        /// <returns>Returns the HttpResponseMessage</returns>
        public HttpResponseMessage Delete(int id)
        {
            //HttpResponseMessage works with HTTP Protocol to return the data with status/error
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Product Deleted");
            //Try, If there is no exception
            try
            {
                //Object creation for Business Layer
                OnlineCartBL bll = new OnlineCartBL();
                //Calling the Function
                bll.DeleteOrderFromCartById(id);
            }
            //Catch, If any custom exception exists
            catch (OnlineException ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Catch, If any other exception exists
            catch (Exception ex)
            {
                msg = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returning the response message status
            return msg;
        }
    }
}
