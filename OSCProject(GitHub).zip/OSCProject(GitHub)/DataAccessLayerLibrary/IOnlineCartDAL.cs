﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineCartEntitiesLib;//Using Entities Library
namespace OnlineCartDataAccessLayerLib
{
    /// <summary>
    /// Inerface to the Data Access Layer which makes it to implement all the listed methods
    /// </summary>
    public interface IOnlineCartDAL
    {
        //Method to get the list of products based on the Category Name searched
        List<Product> GetProductsByCategoryName(string name);
        //Method to get the list of products based on the Product Name searched
        List<Product> GetProductsByProductName(string name);
        //Method to get the Product Details based on the Product Id
        Product GetProductDetailsById(int id);
        //Method to get All the Categories present in the site
        List<OnlineCategory> GetAllCategories();
        //Method to Add the Product to Cart 
        void AddToCart(List<OrderProduct> lstOp);
        //Method to Display the Product Details present in the Cart
        List<OrderProduct> GetCartDetails();
        //Method to Post the Product from Cart to Place the Order
        void PostToCart(OrderProduct op);
        //Method to Delete the Product when it is placed for the order
        void DeleteOrderFromCartById(int id);
        //Method to Get the Username of the User at the time of Login
        Login GetUsername(string name);
        //Method to Get the Password of the User at the time of Login
        Login GetPassword(string pwd);
    }
}
