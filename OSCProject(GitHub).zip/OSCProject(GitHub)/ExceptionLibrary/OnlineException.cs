﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineCartExceptionLib
{
    //Custom Exception Class
    public class OnlineException : Exception
    {
        //Custom Exception Constructor
        public OnlineException(string errMsg) : base(errMsg)
        {

        }
    }
}
