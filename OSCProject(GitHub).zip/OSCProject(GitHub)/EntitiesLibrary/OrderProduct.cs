﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineCartEntitiesLib
{
    /// <summary>
    /// Product having some details which we want to order
    /// </summary>
    public class OrderProduct
    {
        //Propery to store the Product Id for particular product
        public int ProductId { get; set; }
        //Property to store the Product Name
        public string ProductName { get; set; }
        //Property to store the Price of the Product
        public double Price { get; set; }
        //Property to store the Image of the product
        public string Image { get; set; }
        //Property to store the Quantity of the product to buy
        public int Quantity { get; set; }
    }
}
