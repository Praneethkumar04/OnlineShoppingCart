﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineCartEntitiesLib
{
    /// <summary>
    /// Login facility for the site at the time of ordering of products
    /// </summary>
    public class Login
    {
        //Property to store the Username of the User
        public string UserName { get; set; }
        //Property to store the Password of the User
        public string Password { get; set; }
    }
}
