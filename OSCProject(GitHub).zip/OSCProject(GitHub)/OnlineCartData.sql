﻿insert into tbl_category values(1,'Electronics')
insert into tbl_category values(2,'Clothing')
insert into tbl_category values(3,'Furniture')
insert into tbl_category values(4,'Sports')
insert into tbl_category values(5,'Books')

select * from tbl_category

insert into tbl_product values(1,1,'RedMi Note 8','note8.jpg',11499.00, 'Flat 5% discount on ICICI and HDFC Credit Cards', 
'BrandName: RedMi, Memory: 4 GB RAM 64 GB ROM Expandable Upto 512 GB, ScreenSize: 16.0 cm (6.3 inch) Full HD+ Display, Batery: 4000 mAh Lithium Polymer Battery')

insert into tbl_product values(2,1,'Realme C15','realmec15.jpg',10999.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: RealMe, Memory: 4 GB RAM 64 GB ROM Expandable Upto 512 GB, ScreenSize: 16.56 cm (6.52 inch) HD+ Display, Batery: 6000 mAh Lithium Ion Battery')

insert into tbl_product values(3,1,'Oppo A83','oppoA83.jpg',7490.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: Oppo, Memory: 4 GB RAM 64 GB ROM Expandable Upto 512 GB, ScreenSize: 14.48 cm (5.7 inch) HD+ Display, Batery: 3180 mAh Battery')

insert into tbl_product values(4,1,'Iphone 8 Plus','iphone8plus.jpg',49900.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: Iphone, Memory: 4 GB RAM 64 GB ROM, ScreenSize: 13.97 cm (5.5 inch) HD+ Display, Batery: 4080 mAh Battery')

insert into tbl_product values(5,1,'Samsung TV','samsung.jpg',27999.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: Samsung, Operating System: Android(Google Assistant), Resolution: HD Ready 1366 x 768 Pixels')

insert into tbl_product values(6,1,'LG TV','lg.jpg',15999.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: LG, Operating System: Web OS, Resolution: HD Ready 1366 x 768 Pixels')

insert into tbl_product values(7,1,'Boat Rockers Ear Phones','boat.jpg',2599.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: BoatRockers, Color: Black, Supports: Bluetooth and Wireless Time Tracking')

insert into tbl_product values(8,2,'Mens Shrit','shirt1.jpg',1250.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: Louis Phillippe, Color: Red, Size: M | L | XL')

insert into tbl_product values(9,2,'Mens Shrit','shirt2.jpg',1150.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: Louis Phillippe, Color: Black, Size: M | L | XL')

insert into tbl_product values(10,2,'Girls Tops','tops1.jpg',450.00,'Flat 2% discount on ICICI and HDFC Credit Cards',
'BrandName: Novus Creations, Color: Pink, Size: M | L | XL')

insert into tbl_product values(11,2,'Girls Tops','tops2.jpg',550.00,'Flat 2% discount on ICICI and HDFC Credit Cards',
'BrandName: Fabstone, Color: Blue, Size: M | L | XL')

insert into tbl_product values(12,3,'SofaSet','sofa.jpg',38000.00,'Flat 10% discount on ICICI and HDFC Credit Cards',
'BrandName: Bharat Lifestyle, Color: Brown, Filling Material: Foam and Polyfill')

insert into tbl_product values(13,3,'SofaSet','sofa2.jpg',17800.00,'Flat 5% discount on ICICI and HDFC Credit Cards',
'BrandName: Muebles Casa Chroma, Color: Beige, Filling Material: Foam')

insert into tbl_product values(14,4,'CricketBat','bat.jpg',800.00,'Flat 3% discount on ICICI and AXIS Credit Cards',
'BrandName: Kokaburrah, Weight: 1-1.2 KG')

insert into tbl_product values(15,4,'CricketBat','bat2.jpg',480.00,'Flat 2% discount on ICICI and AXIS Credit Cards',
'BrandName: MRF, Weight: 1KG')

insert into tbl_product values(16,5,'Medical Entrance Book','medical.jpg',700.00,'Flat 3% discount on ICICI and AXIS Credit Cards',
'Brand: Pedagogy, Duration: 1 Year, Description: Useful for the students who wants to crack their medical entrance exam')

insert into tbl_product values(17,5,'ASP .NET MVC','asp.jpg',795.00,'Flat 2% discount on ICICI and AXIS Credit Cards',
'Publisher: Springer India Pvt.Ltd., Description: Useful for the students who wants to get knowledge about ASP .NET and MVC')

select * from tbl_product

insert into tbl_UserDetail values('puvvadapraneeth@gmail.com','Praneeth','Satya','Satya')

select * from tbl_UserDetail

select * from tbl_order