﻿using OnlineCartEntitiesLib;//Using Entities Library
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineCartDataAccessLayerLib;//Using the Data Access Layer Library
using OnlineCartExceptionLib;//Using the Exception Library

namespace OnlineCartBusinessLayerLib
{
    public class OnlineCartBL : IOnlineCartBL
    {
        /// <summary>
        /// //Method to Add the Product to Cart 
        /// </summary>
        /// <param name="lstOp">Takes the Parameter as List of OrderProduct</param>
        public void AddToCart(List<OrderProduct> lstOp)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function
                dal.AddToCart(lstOp);
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to Delete the Product when it is placed for the order
        /// </summary>
        /// <param name="id">Takes the parameter as Product Id</param>
        public void DeleteOrderFromCartById(int id)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function
                dal.DeleteOrderFromCartById(id);
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to get All the Categories present in the site
        /// </summary>
        /// <returns>Returns the List of OnlineCategory</returns>
        public List<OnlineCategory> GetAllCategories()
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var lstCat = dal.GetAllCategories();
                //Returns the variable
                return lstCat;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to Display the Product Details present in the Cart
        /// </summary>
        /// <returns>Returns the List of OrderProduct</returns>
        public List<OrderProduct> GetCartDetails()
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var lstOp = dal.GetCartDetails();
                //Returns the variable
                return lstOp;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to Get the Password of the User at the time of Login
        /// </summary>
        /// <param name="pwd">Takes the Parameter as Password</param>
        /// <returns>Returns the Login Object</returns>
        public Login GetPassword(string pwd)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var pswd = dal.GetPassword(pwd);
                //Returns the variable
                return pswd;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to get the Product Details based on the Product Id
        /// </summary>
        /// <param name="id">Takes the parameter as Product Id</param>
        /// <returns>Returns the Object of Product</returns>
        public Product GetProductDetailsById(int id)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var prd = dal.GetProductDetailsById(id);
                //Returns the variable
                return prd;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to get the list of products based on the Category Name searched
        /// </summary>
        /// <param name="name">Takes the Parameter as Category Name</param>
        /// <returns>Returns the Object of the List of Product</returns>
        public List<Product> GetProductsByCategoryName(string name)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var lstPrdt = dal.GetProductsByCategoryName(name);
                //Returns the variable
                return lstPrdt;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to get the list of products based on the Product Name searched
        /// </summary>
        /// <param name="name">Takes the Parameter as Product Name</param>
        /// <returns>Returns the Object of the List of Product</returns>
        public List<Product> GetProductsByProductName(string name)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var lstPdt = dal.GetProductsByProductName(name);
                //Returns the variable
                return lstPdt;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to Get the Username of the User at the time of Login
        /// </summary>
        /// <param name="name">Takes the parameter as Username</param>
        /// <returns>Returns the Login Object</returns>
        public Login GetUsername(string name)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the Function and Storing the value to a variable
                var username = dal.GetUsername(name);
                //Returns the variable
                return username;
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
        /// <summary>
        /// Method to Post the Product from Cart to Place the Order
        /// </summary>
        /// <param name="op">Takes the parameter OrderProduct</param>
        public void PostToCart(OrderProduct op)
        {
            //Try, If there is no exception
            try
            {
                //Object creation for Data Access Layer
                OnlineCartDAL dal = new OnlineCartDAL();
                //Calling the function
                dal.PostToCart(op);
            }
            //Catch, If an exception exists
            catch (OnlineException ex)
            {
                //Throws an exception
                throw ex;
            }
        }
    }
}
