﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingCartMVCClient.Models
{
    /// <summary>
    /// Product containing these listed details just for the clarification of the user to buy
    /// </summary>
    public class Product
    {
        //Property to store the Product Id of the particular product
        public int ProductId { get; set; }
        //Property to store the Category Id in which category the product belongs to
        public int CategoryId { get; set; }
        //Property to store the Product Name
        public string ProductName { get; set; }
        //Property to store the Image of the Product
        public string Image { get; set; }
        //Property to store the Price of the Product
        public double Price { get; set; }
        //Property to store the Available Offers present to the Product
        public string AvailableOffers { get; set; }
        //Property to store the remaining details as a Content for the Product
        public string Content { get; set; }
        //Method to Split the Data present in the Content
        public string DisplayContent()
        {
            string data = null;
            string[] col = Content.Split(',');
            foreach(var item in col)
            {
                string colName, colValue;
                string[] cols = item.Split(':');
                colName = cols[0];
                colValue = cols[1];
                data += "<b>"+colName+"</b>"+":" + colValue+"<br/><br/>";
            }
            return data;
        }
    }
}