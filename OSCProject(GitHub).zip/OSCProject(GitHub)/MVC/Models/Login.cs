﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineShoppingCartMVCClient.Models
{
    /// <summary>
    /// Login facility for the site at the time of ordering of products
    /// </summary>
    public class Login
    {
        //Property to store the Username of the User
        [Required(ErrorMessage = "UserName must not be empty")]
        [StringLength(15, MinimumLength = 3, ErrorMessage = "UserName must be between 3 and 15 characters")]
        public string UserName { get; set; }

        //Property to store the Password of the User
        [Required(ErrorMessage = "Password must not be empty")]
        [StringLength(15, MinimumLength = 3, ErrorMessage = "Password must be between 3 and 15 characters")]
        public string Password { get; set; }
    }
}