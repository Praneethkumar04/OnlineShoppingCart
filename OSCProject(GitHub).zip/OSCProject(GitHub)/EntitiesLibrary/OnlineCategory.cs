﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineCartEntitiesLib
{
    /// <summary>
    /// Category present in the Online Shopping Site
    /// </summary>
    public class OnlineCategory
    {
        //Categrory Id of the particular category
        public int CategoryId { get; set; }
        //Category Name of the particular category
        public string CategoryName { get; set; } 
    }
}
