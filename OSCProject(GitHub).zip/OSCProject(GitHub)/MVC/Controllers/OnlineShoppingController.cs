﻿using Newtonsoft.Json;
using OnlineShoppingCartMVCClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Mvc;

namespace OnlineShoppingCartMVCClient.Controllers
{
    public class OnlineShoppingController : Controller
    {
        // GET: OnlineShopping
        /// <summary>
        /// ActionResult to display the HomePage
        /// </summary>
        /// <returns></returns>
        public ActionResult HomePage()
        {
            //LocalHost Connection of API
            Uri uri = new Uri("http://localhost:58092/api/");
            //Calling the API
            using (var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("OnlineShopping").Result;
                //Deserializing the Json Object to C# 
                var lstCat = JsonConvert.DeserializeObject<List<OnlineCategory>>(result);
                //Returning View
                return View(lstCat);
            }
        }
        /// <summary>
        /// ActionResult to get the Products List by searching with Product Name
        /// </summary>
        /// <param name="name">Takes the Parameter as Product Name</param>
        /// <returns>Returns the List of Products</returns>
        public ActionResult SearchByProductName(string name)
        {
            //LocalHost Connection of API
            Uri uri = new Uri("http://localhost:58092/api/OnlineShopping/");
            //Calling the API
            using (var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("GetProductsByProductName/" + name).Result;
                //Deserializing the Json Object to C# 
                var lstPrdt = JsonConvert.DeserializeObject<List<Product>>(result);
                //Returning View
                return View(lstPrdt);
            }
        }
        /// <summary>
        /// ActionResult to get the Products List by searching with Category Name
        /// </summary>
        /// <param name="name">Takes the Parameter as Category Name</param>
        /// <returns>Returns the List of Products</returns>
        public ActionResult SearchByCategoryName(string name)
        {
            //LocalHost Connection of API
            Uri uri = new Uri("http://localhost:58092/api/OnlineShopping/");
            //Calling the API
            using (var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("GetProductsByCategoryName/" + name).Result;
                //Deserializing the Json Object to C# 
                var lstPdt = JsonConvert.DeserializeObject<List<Product>>(result);
                //Returning View
                return View(lstPdt);
            }
        }
        /// <summary>
        /// ActionResult to Display the Product Details
        /// </summary>
        /// <param name="id">Takes the Parameter as Product Id</param>
        /// <returns>Returns the Product Details</returns>
        public ActionResult DisplayProductDetails(int id)
        {
            //LocalHost Connection of API
            Uri uri = new Uri("http://localhost:58092/api/OnlineShopping/");
            //Calling the API
            using (var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("GetProductDetailsById/" + id).Result;
                //Deserializing the Json Object to C# 
                var prd = JsonConvert.DeserializeObject<Product>(result);
                //Returning View
                return View(prd);
            }
        }
        [HttpGet]
        public ActionResult AddToCart()
        {
            return View();
        }
        /// <summary>
        /// ActionResult to add the products to the Cart
        /// </summary>
        /// <param name="op">Takes the Parameter OrderProduct</param>
        /// <returns>Returns to the HomePage</returns>
        [HttpPost]
        public ActionResult AddToCart(OrderProduct op)
        {
            //Setting the Quantity to 1 
            op.Quantity = 1;
            //Checking the condition, If Session is empty or not
            if (Session["cart"] == null)
            {
                //Creating the Object for List of OrderProduct
                List<OrderProduct> items = new List<OrderProduct>();
                //Adding the Product to the List
                items.Add(op);
                //Adding that List to the Session
                Session.Add("cart", items);
            }
            //If the Session is not empty
            else
            {
                //Gets the Cart from Session
                var cartLst = (List<OrderProduct>)Session["cart"];
                //Adding the next product to the List
                cartLst.Add(op);
                //Adding that List to the Session
                Session.Add("cart", cartLst);
            }
            //Redirecting to HomePage View
            return RedirectToAction("HomePage");
        }
        /// <summary>
        /// ActionResult to Display the Products present in the Cart 
        /// </summary>
        /// <returns>Returns the List of Products</returns>
        public ActionResult DisplayCart()
        {
            //Gets the Cart from Session
            var cartLst = (List<OrderProduct>)Session["cart"];
            //Adding that List to the Session
            Session.Add("cartList", cartLst);
            //Returning View
            return View(cartLst);
        }
        /// <summary>
        /// ActionResult to Post the Products to place order
        /// </summary>
        /// <returns></returns>
        public ActionResult PostToCart()
        {
            //Gets the Cart from Session
            var cartLst = (List<OrderProduct>)Session["cartList"];
            //Calling API
            using(var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = new Uri("http://localhost:58092/api/OnlineShopping/");
                //Sends a Post Request to the Specified Uri
                var result = client.PostAsJsonAsync<List<OrderProduct>>("AddToCart", cartLst).Result;
            }
            //Returning View
            return View(cartLst);
        }
        /// <summary>
        /// ActionResult to Get the Final Message to the User
        /// </summary>
        /// <returns></returns>
        [Authorize]//Used for Authorization
        public ActionResult GetFromCart()
        {
            //Gets the Cart from Session
            var cartList = (List<OrderProduct>)Session["cartList"];
            //Clearing the cart after placing the order
            cartList.Clear();
            //Making the Session Empty
            Session["cart"] = cartList;
            //Returning View
            return View();
        }
        /// <summary>
        /// ActionResult to delete the products in the session
        /// </summary>
        /// <param name="id">Takes the Parameter as Product Id</param>
        /// <returns></returns>
        public ActionResult DeleteFromCart(int id)
        {
            //Gets the Cart from Session
            var cartLst = (List<OrderProduct>)Session["cartList"];
            //Checks the given Id and ProductId equals or not and 
            //Returns the first element of a sequence, or a default value if the sequence contains no elements
            var prdt = cartLst.Where(o => o.ProductId == id).FirstOrDefault();
            //Removing the Product from the List
            cartLst.Remove(prdt);
            //Assigning the List to the Session
            Session["cart"] = cartLst;
            //Redirecting to HomePage View
            return RedirectToAction("HomePage");
        }
        /// <summary>
        /// ActionResult to Delete the Product from database after placing the order
        /// </summary>
        /// <param name="id">Takes the Parameter as Product Id</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult DeleteOrderFromCart(int id)
        {
            //LocalHost Connection of API
            Uri uri = new Uri("http://localhost:58092/api/");
            //Calling API
            using (var client = new HttpClient())
            {
                //Setting the BaseAddress
                client.BaseAddress = uri;
                //Sends a Delete Request to the Specified Uri
                var result = client.DeleteAsync("OnlineShopping/" + id).Result;
            }
            //Redirecting to the HomePage View
            return RedirectToAction("HomePage");
        }
        /// <summary>
        /// ActionResult to Update the Quantity of the Product
        /// </summary>
        /// <param name="id">Takes the Parameter as Product Id</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult UpdateQuantity(int id)
        {
            //Gets the Cart from Session
            var cartLst = (List<OrderProduct>)Session["cartList"];
            //Checks the given Id and ProductId equals or not and 
            //Returns the first element of a sequence, or a default value if the sequence contains no elements
            var prdt = cartLst.Where(o => o.ProductId == id).FirstOrDefault();
            //Returning View
            return View(prdt);
        }
        [HttpPost]
        public ActionResult UpdateQuantity(OrderProduct op)
        {
            //Gets the Cart from Session
            var cartLst = (List<OrderProduct>)Session["cartList"];
            //Checks the given Id and ProductId equals or not and 
            //Returns the first element of a sequence, or a default value if the sequence contains no elements
            var prdt = cartLst.Where(o => o.ProductId == op.ProductId).FirstOrDefault();
            //Assigning the changed quantity to the Product quantity 
            prdt.Quantity = op.Quantity;
            //Assigning the List to the Session
            Session["cartList"] = cartLst;
            //Redirecting to the DisplayCart View
            return RedirectToAction("DisplayCart");
        }
    }
}